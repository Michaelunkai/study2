Vssadmin list writers 
#List subscribed volume shadow copy writers 