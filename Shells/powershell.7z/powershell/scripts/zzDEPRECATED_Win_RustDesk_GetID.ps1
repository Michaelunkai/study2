# No Longer working please use from https://docs.tacticalrmm.com/3rdparty_rustdesk/
$ErrorActionPreference = 'silentlycontinue'

Write-output ".............................................................................................................................."
Write-output "Script doesn't work and won't be updated please obtain up to date scripts from https://docs.tacticalrmm.com/3rdparty_rustdesk/"
Write-output ".............................................................................................................................."
exit 20
