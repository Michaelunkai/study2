# Sleep for 6 hours (6 hours * 60 minutes * 60 seconds)
Start-Sleep -Seconds (6 * 60 * 60)

# Run qBittorrent.exe from the specified path
Start-Process -FilePath "C:\Program Files\qBittorrent\qbittorrent.exe"


