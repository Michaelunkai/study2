# GET NETWORK STATUS PRIVATE/PUBLIC/HOME/WORK
Get-NetConnectionProfile
Set-NetConnectionProfile -InterfaceIndex <index number> -NetworkCategory Private
