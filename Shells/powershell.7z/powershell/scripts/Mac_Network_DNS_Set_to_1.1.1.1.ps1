networksetup -setdnsservers Wi-Fi 1.1.1.1
networksetup -setdnsservers Wi-Fi 1.0.0.1
networksetup -setdnsservers Ethernet 1.1.1.1
networksetup -setdnsservers Ethernet 1.0.0.1