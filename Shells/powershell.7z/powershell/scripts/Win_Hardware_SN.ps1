# Get BIOS Serial Number for Collectors
Get-WmiObject Win32_BIOS | Select SerialNumber