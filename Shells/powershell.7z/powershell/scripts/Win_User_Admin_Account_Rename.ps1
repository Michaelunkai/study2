#Needs random name
#Needs parameter support


Rename-LocalUser -Name "Administrator" -NewName "LocalAdmin"
