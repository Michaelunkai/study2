# Optimize the VHDX file (Full Optimization)
Optimize-VHD -Path "D:\backup\linux\ext4.vhdx" -Mode Full

# Compact the VHDX file (Quick Mode)
Optimize-VHD -Path "D:\backup\linux\ext4.vhdx" -Mode Quick
