Vssadmin list providers 
#List registered volume shadow copy providers 