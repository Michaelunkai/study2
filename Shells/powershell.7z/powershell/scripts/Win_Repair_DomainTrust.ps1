###
# Author: Dave Long <dlong@cagedata.com>
# Tests and attempts to repair the domain trust relationship between a domain
# joined computer and the domain.
###

Test-ComputerSecureChannel -Repair