#Check what domain a devices is joined to.
$ErrorActionPreference= 'silentlycontinue'

Write-Output "$Env:UserDomain"
