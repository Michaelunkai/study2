Vssadmin delete shadows 
#Deletes volume shadow copies 