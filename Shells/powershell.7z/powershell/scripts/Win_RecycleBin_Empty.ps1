# Must be "Run As User"
Clear-RecycleBin -Confirm:$false -ErrorAction SilentlyContinue