# Sleep for 10 seconds
Start-Sleep -Seconds 10

# Run qBittorrent.exe from the specified path
Start-Process -FilePath "C:\Program Files\qBittorrent\qbittorrent.exe"
