rem https://helpcenter.veeam.com/docs/agentforwindows/userguide/backup_cmd.html?ver=60

"C:\Program Files\Veeam\Endpoint Backup\Veeam.EndPoint.Manager.exe" /backup