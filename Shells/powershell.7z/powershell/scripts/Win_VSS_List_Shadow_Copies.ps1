Vssadmin list shadows 
#List existing volume shadow copies 