#!/bin/bash
# Enable caching for faster disk access
hdparm -W1 /dev/sda
