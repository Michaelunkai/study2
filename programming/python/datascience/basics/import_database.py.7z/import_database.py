import pandas as pd

# Load dataset
data = pd.read_ ('<DatasetName>. ')
print(data)
