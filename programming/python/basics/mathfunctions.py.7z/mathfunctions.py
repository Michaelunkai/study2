import math

pi = 3.14
x = 1
y = 2
z = 3

#print(round(pi))
#print(math.celi(pi))
#print(math.floor(pi))
#print(abs(pi))
#print(pow(pi,2))
#print(math.sqrt(420))
#print(max(x,y,z))
#print(min(x,y,z))