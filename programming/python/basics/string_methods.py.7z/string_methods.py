# # string methods

# name = "Bro"

# # print(len(name))
# #to find a character within a string:
# # print(name.find("B"))
# print(name.capitalize())
# print(name.upper())
# print(name.lower())
# print(name.isdigit())
# print(name.isalptha())
# print(name.count("O"))
# print(name.repace("o", "a"))
# print(name.replace("o", "a"))
# print(name*3)