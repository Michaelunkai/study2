# # # list = used to store multiple items in a single variable

# # # food = ['pizza','humburger','hotdog','spaghetti','pudding']

# # # print(food[0])
# # # this will print 'pizza'. [1] woll print humburger etc..
# # # [4] = pudding (the 5th)


# # food = ['pizza','humburger','hotdog','spaghetti','pudding']
# # food[0] = 'sushi'
# # print(food[0])
# # # this will print sushi. now pizza will be number 1 instead of 0 and same for all the others

# # food = ['pizza','humburger','hotdog','spaghetti','pudding']
# # food[0] = 'sushi'
# # for x in food:
# #     print(x)
# # using this 'for loop', the output will print all the list items, each line at a time

# # functions of lists:

# # food = ['pizza','humburger','hotdog','spaghetti','pudding']
# # food[0] = 'sushi'
# # food.append('ice cream')
# # for x in food:
# #     print(x)
# # this code will print the same as the previous + add new line for 'ice cream' at the end

# # food = ['pizza','humburger','hotdog','spaghetti','pudding']
# # food[0] = 'sushi'
# # food.remove('hotdog')
# # for x in food:
# #     print(x)
# # this will print all the list, witout 'hotdog'

# food = ['pizza','humburger','hotdog','spaghetti','pudding']
# food[0] = 'sushi'
# food.pop()
# for x in food:
#     print(x)
# # this will print the same list, but will remove the last item

# food = ['pizza','humburger','hotdog','spaghetti','pudding']
# food[0] = 'sushi'
# food.insert(0,'cake')
# for x in food:
#     print(x)
# this code will print the list + add item named 'cake' as the first entry

# food = ['pizza','humburger','hotdog','spaghetti','pudding']
# food[0] = 'sushi'
# food.sort()
# for x in food:
#     print(x)
# will print the list in alpabthetic oreder

# food = ['pizza','humburger','hotdog','spaghetti','pudding']
# food[0] = 'sushi'
# food.clear()
# for x in food:
#     print(x)
#  will remove all the elements of a list

