# Get user input
user_name = input('Enter your name: ')

# Perform basic operations
num1 = int(input('Enter a number: '))
num2 = int(input('enter another number: '))
sum_result = num1 + num2
product_result = num1 * num2

# Print results
print('Hello, ' + user_name + '!')
print('Sum:', sum_result)
print('Product:', product_result)