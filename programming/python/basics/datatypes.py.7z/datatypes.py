# Integer
age = 25

# Float
height = 5.9

# String
name = "John"

# Printing these variables
print("Age:", age)
print("Height:", height)
print("Name:", name)
