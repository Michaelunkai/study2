import matplotlib.pyplot as plt

# Sample data
categories = ['A', 'B', 'C', 'D']
values = [10, 15, 7, 12]

# Create a bar chart
plt.bar(categories, values)

# Display the plot
plt.show()