import pandas as pd

# Load data from a CSV file
data = pd.read_csv('data.csv')

# Display the first few rows
print(data.head())