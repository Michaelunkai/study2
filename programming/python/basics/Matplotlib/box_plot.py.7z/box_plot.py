import matplotlib.pyplot as plt

# Sample data
data = [20, 22, 23, 24, 25, 30, 32, 33, 35, 37, 40]

# Create a box plot
plt.boxplot(data)

# Display the plot
plt.show()