import matplotlib.pyplot as plt

# Sample data
x = [5, 7, 8, 7, 2, 17]
y = [99, 86, 87, 88, 111, 86]

# Create a scatter plot
plt.scatter(x, y)

# Display the plot
plt.show()