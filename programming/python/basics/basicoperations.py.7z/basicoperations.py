# Addition
result_add = 10 + 5

# Subtraction
result_sub = 10 - 5

# Multiplication
result_mul = 10 * 5

# Division
result_div = 10 / 5

# Modulus (remainder after division)
result_mod = 10 % 3

# Exponentiation
result_exp = 2 ** 3

# Printing the results
print("Addition:", result_add)
print("Subtraction:", result_sub)
print("Multiplication:", result_mul)
print("Division:", result_div)
print("Modulus:", result_mod)
print("Exponentiation:", result_exp)