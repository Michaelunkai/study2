# # # index opeator [] = gives access to a sequence's element (str,list,tuples)
# # # this example is for str:

# # # name = 'misha'

# # # if(name[0].islower()): 
# # #     name = name.capitalize()

# # # print(name)
# # # this code checks if the first letter of my variable (0=first) is capitalize. if not, it will capitlize it.
# # #  output: Misha

# # # creating sun strings with my index operator:
# # name = 'misha fedro'
# # first_name = name[0:3].upper()
# # print(first_name)
# # # this code will print the first 3 letter in my name in appercase letters. output: MIS

# # substring for last name:
# # name = 'misha fedro'
# # first_name = name[:5].capitalize()
# # last_name = name[6:].capitalize()
# # print(first_name, last_name)
# # output: Misha Fedro

# # name = 'misha fedro'
# # first_name = name[:5].upper()
# # last_name = name[6:].lower()
# # last_character = name[-1]

# # print(first_name)
# # print(last_name)
# # print(last_character)

# # output:
# MISHA
# fedro
# o
