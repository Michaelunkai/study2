contacts = ['John Doe', 'Jane Smith', 'Emily Davis']

print("Contacts:")
for idx, contact in enumerate(contacts, start=1):
    print(f"{idx}. {contact}")