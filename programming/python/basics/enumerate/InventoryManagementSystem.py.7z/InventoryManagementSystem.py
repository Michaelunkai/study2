inventory = ['Apples', 'Bananas', 'Cherries']

print("Inventory:")
for idx, item in enumerate(inventory, start=1):
    print(f"{idx}. {item}")