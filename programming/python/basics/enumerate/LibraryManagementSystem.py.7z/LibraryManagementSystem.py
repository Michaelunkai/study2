books = ['1984 by George Orwell', 'To Kill a Mockingbird by Harper Lee', 'The Great Gatsby by F. Scott Fitzgerald']

print("Available Books:")
for num, book in enumerate(books, start=1):
    print(f"{num}. {book}")
