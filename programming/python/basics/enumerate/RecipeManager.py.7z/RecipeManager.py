recipes = ['Spaghetti Bolognese', 'Chicken Curry', 'Beef Stroganoff']

print("Recipes:")
for index, recipe in enumerate(recipes, start=1):
    print(f"{index}. {recipe}")
