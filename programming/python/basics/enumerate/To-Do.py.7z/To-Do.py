tasks = ['buy groceries', 'call yasha', 'eat steak']

print('To-Do List:')
for index, task in enumerate(tasks, start=1):
    print(f"{index}. {task}")