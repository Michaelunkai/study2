expenses = ['Rent: $1200', 'Groceries: $300', 'Utilities: $150']

print("Expenses:")
for idx, expense in enumerate(expenses, start=1):
    print(f"{idx}. {expense}")
