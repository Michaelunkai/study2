tasks = ['Meeting at 10 AM', 'Lunch with Sarah', 'Gym at 6 PM']

print("Today's Schedule:")
for idx, task in enumerate(tasks, start=1):
    print(f"{idx}. {task}")
