#example:

from PIL import Image

# Load the PNG image
image = Image.open("/mnt/c/Users/micha/Downloads/1779940.png")

# Save as ICO format
image.save("/mnt/c/Users/micha/Downloads/1779940.ico")
