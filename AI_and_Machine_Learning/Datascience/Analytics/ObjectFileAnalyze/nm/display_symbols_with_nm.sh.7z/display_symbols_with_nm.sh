#!/bin/bash
nm /usr/bin/ls > nm_output.txt
