#!/bin/ 
hexyl /usr/bin/ls > hexyl_output.txt
