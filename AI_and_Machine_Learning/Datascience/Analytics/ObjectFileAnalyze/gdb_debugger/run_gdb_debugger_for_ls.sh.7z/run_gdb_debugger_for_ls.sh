#!/bin/ 
echo "run" | gdb /usr/bin/ls > gdb_output.txt

