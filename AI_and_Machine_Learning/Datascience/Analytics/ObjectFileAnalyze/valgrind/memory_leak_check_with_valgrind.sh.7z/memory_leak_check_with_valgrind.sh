#!/bin/ 
valgrind /usr/bin/ls > valgrind_output.txt
