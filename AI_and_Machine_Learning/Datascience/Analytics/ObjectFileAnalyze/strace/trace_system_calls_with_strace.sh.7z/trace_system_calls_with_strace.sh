#!/bin/ 
strace /usr/bin/ls > strace_output.txt
