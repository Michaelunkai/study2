#!/bin/ 
sudo apt install mousepad && mousepad